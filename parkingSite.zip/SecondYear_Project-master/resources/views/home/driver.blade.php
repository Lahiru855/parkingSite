<div class="row">
    <div class="col-md-6">
      <div class="header_video">
        <a href="#"><img src="{{ URL::asset('assets/img/driver.jpg')}}" alt="Driver image" height="350" width="500"></a>
          <!-- <iframe src="https://www.youtube.com/embed/bM4G1Toe3h0" frameborder="0" allowfullscreen></iframe> -->
      </div>
    </div>
    <div class="col-md-6">
      <div class="text">
          <h3>Want to enjoy easy parking? </h3>
          <h6><p>Fed up of overpaying for parking and getting tickets for parking violations? </p> <p>Get directions to the nearest parking space.</p></h6>
          <a class="button white" href="#">F A Q <sub>s</sub></a>
          <a class="button" href="signup">Get Started</a>
      </div>
    </div>
</div>
