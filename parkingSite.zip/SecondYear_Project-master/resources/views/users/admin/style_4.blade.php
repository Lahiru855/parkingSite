<style media="screen">
* {
box-sizing: border-box;
}
body{
  background-color: #fff;
  text-align: center;
font-family: 'Source Sans Pro', Helvetica;
}
#container{
  margin: 100px auto;
  width: 90%;
  text-align: left;
position: relative;
}
.widget{
  background-color: #fff;
  font: 11pt Georgia,Times,serif;
  color: #333;
  padding: 7px;
  /*margin: 20px;*/
  width: 100%;
}
  .widget ul{
      list-style-position: inside;
  }
.widget h5{
  font-size: 14pt;
  margin: 5px;
}
.new-widget{
  margin: 0px;
  border: 1px solid #ddd;
border-top: 0;
  background-color: #fff;
  /*padding: 7px;*/
  width: 100%;
  clear: both;
}
  .new-widget ul{
      display: none;
  }
.tab-wrapper{
/*  margin-left: 1px; */
width: 1000px;
padding: 0;
/*  height: 0px; */
/*  background: #1abc9c;  */
}
.tab{
/* width: 100px;*/
padding: 8px 10px;
margin-right: 5px;
font-size: 0.9em;
/*   border: 1px solid red; */
  border-radius: 10px 10px 0 0;
/* height: 33px; */
  float: left;
  background: #eee;
  text-transform: capitalize;
  color: #333;
  text-align: center;
  /* line-height: 2.0em; */
  cursor: pointer;
  list-style: none!important;
transition: all 200ms;
/*   border-right: 0.125rem solid #16a085; */
  border-top: 1px solid #ddd;
  border-right: 1px solid #ddd;
  border-left: 1px solid #ddd;
}
.tab:hover {
background: #f0554a;
color: #fff;
}
.active-tab{
  background: #f0554a;
color: #fff;
}
.active-tab:hover {
}
.tab-content {
padding: 0 0;
}
/* TABLE STYLING */
.group-table caption {
  background:#f0554a;
color: #fff;
padding: 8px;
font-size: 1.4em;
}
.group-table {
  border-top: 1px solid #ddd;
width:100%;
  /*  border:1px solid #ddd; */
/*    border-top: none;  */
  border-collapse:collapse;
      padding:5px;
  text-align: center;
  }
  .group-table th {
  /*  border:1px solid #ddd;
  border-top: none; */
      padding: 10px 5px;
  font-weight: normal;
      background:#f0554a;
  color: #fff;
  }
  .group-table td {
  /*  border:1px solid #ddd; */
      padding:10px 2px;
  }
td:nth-child(3) {
  /* min-width: 90px; */
}
.group-table th, .group-table td {
border-right: 1px solid #ddd;
}
.group-table th:last-child, .group-table td:last-child {
border-right: none;
}
.group-table tr:nth-child(odd) {
background: #f0f0f0;
}
#morning .group-table td:nth-child(3) {
background: #fff;
}
.group-table td.align-bottom {
vertical-align: bottom;
padding: 0;
}
.group-table td.align-top {
vertical-align: top;
padding: 0;
}
#morning .group-table td:nth-child(3), #afternoon .group-table td:nth-child(3), #evening .group-table td:nth-child(3) {
background: #fff;
}
#weekend .group-table td:nth-child(2) {
background: #fff;
}
</style>