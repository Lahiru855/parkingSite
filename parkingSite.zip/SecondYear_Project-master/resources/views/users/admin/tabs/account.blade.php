
 <link rel="stylesheet" href="{{ URL::asset('assets/myAccount.css') }}">

<nav class="navbar navbar-default navbar-static-top">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="#">
        Logo
      </a>
		</div>
	</div>
</nav>
<main class="container">
	<div class="row">
		<div class="sidebar text-center">
			<img src="https://s3.amazonaws.com/uifaces/faces/twitter/mantia/128.jpg" class="img-circle">
			<h3>User Name</h3>
		</div>
		<div class="content">
			<h1>Title</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium eum consequuntur alias quibusdam, pariatur fugiat iusto fugit totam minus architecto eligendi provident neque id aspernatur quisquam! Doloribus cupiditate, qui dolores.
			</p>
		</div>
	</div>
</main>