<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class adminloginController extends Controller
{
    //

    public function index(){
        // return view('home.signup_login.login.admin.tabs.adminlogin' );
        return view('Temp.5.adminlogin' );
    }

}
